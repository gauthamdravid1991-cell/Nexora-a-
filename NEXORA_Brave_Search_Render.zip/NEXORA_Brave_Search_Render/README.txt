NEXORA — Brave Search + Render
===============================

FILES
- server.js: Node/Express backend. Keeps BRAVE_API_KEY on the server.
- package.json: Node project and start command.
- public/index.html: NEXORA interface; displays results returned by the backend.
- public/manifest.webmanifest: basic install metadata.

IMPORTANT SECURITY
Never paste the Brave API key into index.html, server.js, a public GitHub repository,
or this README. Set it only as a Render environment variable named BRAVE_API_KEY.

DEPLOY TO RENDER (PHONE-FRIENDLY ROUTE)
1. Extract this ZIP.
2. Upload the project files to a NEW private GitHub repository:
   - server.js at the repository root
   - package.json at the repository root
   - public/index.html
   - public/manifest.webmanifest
3. In Render, choose New + Web Service and connect that repository.
4. Runtime/language: Node.
   Build command: npm install
   Start command: npm start
5. In Render service settings, open Environment and add:
   Key: BRAVE_API_KEY
   Value: your Brave API key (paste it only here).
6. Save changes and deploy. Wait for the deploy to finish.
7. Open https://YOUR-SERVICE.onrender.com/api/health
   Expected JSON includes "ok": true and "keyConfigured": true.
8. Open the service root URL. Search for "C++ programming for beginners".
9. If an error occurs, inspect Render Logs. Do not share the API key or screenshots
   that reveal it.

LOCAL LIMITATION
Opening public/index.html directly as a file will not run the API backend. The app
must be served by the Node server or deployed to Render.

ENDPOINTS
- GET /api/health
- GET /api/search?q=your%20query

The backend requests Brave Web Search at
https://api.search.brave.com/res/v1/web/search and uses the X-Subscription-Token header.
