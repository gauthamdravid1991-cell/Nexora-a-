const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const BRAVE_API_KEY = process.env.BRAVE_API_KEY;

app.disable("x-powered-by");
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "NEXORA Search API", keyConfigured: Boolean(BRAVE_API_KEY) });
});

app.get("/api/search", async (req, res) => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";

  if (!q) {
    return res.status(400).json({ error: "Please enter a search query." });
  }
  if (q.length > 600) {
    return res.status(400).json({ error: "Search query must be 600 characters or fewer." });
  }
  if (!BRAVE_API_KEY) {
    return res.status(503).json({ error: "Search is not configured yet. Add BRAVE_API_KEY in Render environment variables." });
  }

  try {
    const url = new URL("https://api.search.brave.com/res/v1/web/search");
    url.searchParams.set("q", q);
    url.searchParams.set("count", "10");
    url.searchParams.set("country", "IN");
    url.searchParams.set("search_lang", "en");
    url.searchParams.set("safesearch", "strict");

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "X-Subscription-Token": BRAVE_API_KEY
      },
      signal: AbortSignal.timeout(15000)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("Brave API returned status:", response.status);
      if (response.status === 401 || response.status === 403) {
        return res.status(502).json({ error: "Brave rejected the API key or plan. Check your key and API plan in the Brave dashboard." });
      }
      if (response.status === 429) {
        return res.status(429).json({ error: "Search rate or plan limit reached. Check your Brave API usage and plan." });
      }
      return res.status(502).json({ error: "The search provider returned an error. Please try again later." });
    }

    const results = (data.web && Array.isArray(data.web.results) ? data.web.results : [])
      .map(item => ({
        title: String(item.title || "Untitled result"),
        url: String(item.url || ""),
        description: String(item.description || "")
      }))
      .filter(item => {
        try {
          const u = new URL(item.url);
          return (u.protocol === "https:" || u.protocol === "http:") && item.url.length < 3000;
        } catch {
          return false;
        }
      });

    res.set("Cache-Control", "no-store");
    return res.json({ query: q, results });
  } catch (error) {
    console.error("Search request failed:", error.name || "Error");
    return res.status(504).json({ error: "Search timed out or the provider could not be reached. Please try again." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`NEXORA server listening on port ${PORT}`);
});
